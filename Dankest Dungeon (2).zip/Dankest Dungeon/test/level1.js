import Shopkeeper from "./shopkeeper.js";
import Character from "./character.js";
import Potion from "./potion.js";
import Wall from "./wall.js";
import Monster from "./monster.js";
import MeanMenu from "./menu.js";
class FirePotion extends Potion {};
class IcePotion extends Potion {};
class ExplosionPotion extends Potion {};
class AcidPotion extends Potion {};
class AcidWall extends Wall {};




export default class LevelOne extends Phaser.Scene {

    constructor(){
        super("LevelOne");
    }

    preload() {
        this.load.image("tiles", "../assets/tilesets/dungeonTileset.png");
        this.load.tilemapTiledJSON("maps", "../assets/tilemaps/dungtest1.json");
        this.load.spritesheet("dragon", "../assets/images/FlameTail v2.png", {frameWidth: 16, frameHeight: 16});
        this.load.image("heart", "../assets/images/heart.png");
        this.load.image("button", "../assets/images/button_button.png");
        this.load.image("exit", "../assets/images/button_exit.png");
        this.load.image("BuyB", "../assets/images/button_buy.png");
        this.load.image("SellB", "../assets/images/button_sell.png");
        this.load.image("FireP", "../assets/images/button_fire-potion.png");
        this.load.image("IceP", "../assets/images/button_ice-potion.png");
        this.load.image("ExplosionP", "../assets/images/button_explosion-potion.png");
        this.load.image("AcidP", "../assets/images/button_acid-potion.png");
        this.load.image("Return", "../assets/images/button_return.png");
        this.load.spritesheet("shopkeeper", "../assets/images/Shopkeeper.png", {frameWidth: 16, frameHeight: 16});
        this.load.image("Inventory", "../assets/images/button_inventory.png");
    }

    create() {
        const map = this.make.tilemap({ key: "maps" });
        var inventory = [];     //initializing the shop inventory
        var pinventory = [];    //initializing the player inventory
        const tileset = map.addTilesetImage("dungeonTileset", "tiles");
        this.floor = map.createStaticLayer("Floor", tileset, 0, 0);
        this.walls = map.createStaticLayer("Wall", tileset, 0, 0);
        this.obstacle = map.createStaticLayer("Obstacle", tileset, 0, 0);
        this.acidW = map.createStaticLayer("Acid Wall", tileset, 0, 0);

        this.walls.setScale(2);
        this.floor.setScale(2);
        this.obstacle.setScale(2);
        this.acidW.setScale(2);

        this.walls.setCollisionByProperty({ collides: true });
        this.obstacle.setCollisionByProperty({ collides: true });
        this.acidW.setCollisionByProperty({ collides: true});

        // Object layers in Tiled let you embed extra info into a map - like a spawn point or custom
        // collision shapes. In the tmx file, there's an object layer with a point named "Spawn Point"
        const spawnPoint = map.findObject("Objects", obj => obj.name === "Spawn Point");
        //object layer spawnpoint for the monsters
        const monsterPoint = map.findObject("Objects", obj => obj.name === "Monster Point");

        //const acidWall = map.findObject("Acid Wall", obj => obj.name === "acid");


        // Create a sprite with physics enabled via the physics system. The image used for the sprite has
        // a bit of whitespace, so I'm using setSize & setOffset to control the size of the player's body.
        this.player = new Character(this, spawnPoint.x, spawnPoint.y, pinventory, 50, 0);

        //shopkeeper
        this.shop = new Shopkeeper(this, 200, 200, inventory);

        this.monster = new Monster(this, monsterPoint.x, monsterPoint.y*3);

        //this.acidW = new AcidWall(this, acidWall.x, acidWall.y, "dragon");


        //adding items
        this.shop.inventory.push(new FirePotion(10, 10, 2, 2, "Fire", "FireP"));
        this.shop.inventory.push(new IcePotion(10, 10, 2, 2, "Ice", "IceP"));
        this.shop.inventory.push(new ExplosionPotion(30, 25, 4, 2, "Explosion", "ExplosionP"));
        this.shop.inventory.push(new AcidPotion(20, 20, 1, 2, "Acid", "AcidP"));


        this.obstacle.setTileIndexCallback(196, this.nextLevel, this);

        //this.obstacle.setTileIndexCallback(134, destroyObject, this);

//        function destroyObject(sprite, tile){
//            this.obstacle.destroy();
//        }

        // Watch the player and worldLayer for collisions, for the duration of the scene:
        this.physics.world.addCollider(this.player.sprite, this.walls);
        this.physics.world.addCollider(this.player.sprite, this.obstacle);
        this.physics.world.addCollider(this.player.sprite, this.acidW);

        // Watch the monster and worldLayer for collisions, for the duration of the scene:
        this.physics.world.addCollider(this.monster.sprite, this.walls);
        //this.physics.world.addCollider(this.monster.sprite, this.obstacle);

        //this.acidW.sprite.setCollideWorldBounds(true);


        //this.physics.world.addCollider(this.player.sprite, this.acidW.sprite);
        //this.acidW.sprite.body.velocity.x = 0;
        //this.acidW.sprite.body.velocity.y = 0;

        //this.player.sprite.setCollideWorldBounds(true);
        //this.shop.sprite.setCollideWorldBounds(true);



        //add interaction for player and shop

        this.overlap = this.physics.add.overlap(this.player.sprite, this.shop.sprite, this.check.bind(this));

        const camera = this.cameras.main;
        camera.startFollow(this.player.sprite);
        camera.setBounds(0, 0, map.widthInPixels*2, map.heightInPixels*2);

        // Help text that has a "fixed" position on the screen
        var x = this.add.text(16, 16, 'Arrow keys to move\nPress "D" to show hitboxes', {
              font: "18px monospace",
              fill: "#000000",
              padding: { x: 20, y: 10 },
              backgroundColor: "#ffffff"
        }).setScrollFactor(0).setDepth(30);

        setTimeout(function () {x.destroy()}, 2000);

        //For finding coordinates to use for functions
        this.input.keyboard.once("keydown_C", event => {
            this.player.x = this.player.sprite.x;
            this.player.y = this.player.sprite.y;
            console.log(this.player.x);
            console.log(this.player.y);
        });

        this.input.keyboard.once("keydown_ESC", event => {
            this.scene.start('MeanMenu');
        });

        // Debug graphics
        this.input.keyboard.once("keydown_D", event => {
        // Turn on physics debugging to show player's hitbox
            this.physics.world.createDebugGraphic();
            // Create worldLayer collision graphic above the player, but below the help text
            const graphics = this.add.graphics().setAlpha(0.75).setDepth(20);
            this.walls.renderDebug(graphics, {
                tileColor: null, // Color of non-colliding tiles
                collidingTileColor: new Phaser.Display.Color(243, 134, 48, 255), // Color of colliding tiles
                faceColor: new Phaser.Display.Color(40, 39, 37, 255) // Color of colliding face edges
            });
        });

        //add player health bar
        var health = [];
        var xcoord = 30;
        var ycoord = 510;
        for(var i = 0; i < 10; i++) {
          health.push(this.add.image(xcoord + i*32,ycoord,'heart'));
          health[i].setScrollFactor(0);
        }
        this.add.text(xcoord, ycoord + 32, "Health").setScrollFactor(0);
    }

    update(time, delta) {
        this.add.text(650, 16, 'Score: ' + this.player.score, {
              font: "18px monospace",
              fill: "#000000",
              padding: { x: 20, y: 10 },
              backgroundColor: "#ffffff"
        }).setScrollFactor(0).setDepth(30);

        this.player.update();

        this.monster.update(this.player.cursors, this.player.sprite, this);

    }

    nextLevel (sprite, tile){
        this.player.x = 0;
        this.player.y = 0;
        this.player.nextLevel = true;
        this.scene.start('LevelTwo', {player: this.player, shop: this.shop});
    }

    check(player, shop){
        this.input.keyboard.once("keydown_A", event => {
            this.player.x = this.player.sprite.x;
            this.player.y = this.player.sprite.y;
            this.currscene = 'LevelOneE';
            this.scene.start('ShopScene', {player: this.player, shop: this.shop, scene: this.currscene});  //call the shop scene
        });
    }

    checkOverlap(player, shop) {
        var boundsA = player.getBounds();
        var boundsB = shop.getBounds();

        return Phaser.Geom.Intersects.RectangleToRectangle(boundsA, boundsB);
    }
}
