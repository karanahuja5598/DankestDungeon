import Shopkeeper from "./shopkeeper.js"
import Character from "./character.js"
import Potion from "./potion.js";
class FirePotion extends Potion {};
class IcePotion extends Potion {};
class ExplosionPotion extends Potion {};
class AcidPotion extends Potion {};


export default class LevelOneE extends Phaser.Scene {

    constructor(){
        super("LevelOneE");
    }

    preload() {
        this.load.image("tiles", "../assets/tilesets/dungeonTileset.png");
        this.load.tilemapTiledJSON("map", "../assets/tilemaps/dungtest1.json");
        this.load.spritesheet("dragon", "../assets/images/FlameTail v2.png", {frameWidth: 16, frameHeight: 16});
        //this.load.image("heart", "../assets/images/heart.png");
        //this.load.image("button", "../assets/images/button_button.png");
        //this.load.image("exit", "../assets/images/button_exit.png");
        //this.load.image("BuyB", "../assets/images/button_buy.png");
        //this.load.image("SellB", "../assets/images/button_sell.png");
        //this.load.image("FireP", "../assets/images/button_fire-potion.png");
        //this.load.image("IceP", "../assets/images/button_ice-potion.png");
        //this.load.image("ExplosionP", "../assets/images/button_explosion-potion.png");
        //this.load.image("AcidP", "../assets/images/button_acid-potion.png");
        this.load.image("Return", "../assets/images/button_return.png");

    }

    create(data) {
        const map = this.make.tilemap({ key: "map" });
        const tileset = map.addTilesetImage("dungeonTileset", "tiles");
        this.floor = map.createStaticLayer("Floor", tileset, 0, 0);
        this.walls = map.createStaticLayer("Wall", tileset, 0, 0);
        this.obstacles = map.createStaticLayer("Obstacle", tileset, 0, 0);
        this.walls.setScale(2);
        this.floor.setScale(2);
        this.obstacles.setScale(2);

        this.walls.setCollisionByProperty({ collides: true });
        this.obstacles.setCollisionByProperty({ collides: true});

        this.tshop = true; //variable set to true so that the player doesn't interact twice with the shop

        // Create a sprite with physics enabled via the physics system. The image used for the sprite has
        // a bit of whitespace, so I'm using setSize & setOffset to control the size of the player's body.
        this.player = new Character(this, data.player.x, data.player.y, data.player.inventory);
        //shopkeeper
        this.shop = new Shopkeeper(this, data.shop.x, data.shop.y, data.shop.inventory);

        // Watch the player and worldLayer for collisions, for the duration of the scene:
        this.physics.world.addCollider(this.player.sprite, this.walls);
        this.physics.world.addCollider(this.player.sprite, this.obstacles);

        this.obstacles.setTileIndexCallback(196, nextLevel, this);

        function nextLevel (sprite, tile){
            this.player.x = 0;
            this.player.y = 0;
            this.player.nextLevel = true;
            this.scene.start('LevelTwo', {player: this.player, shop: this.shop});
        }

        //this.player.sprite.setCollideWorldBounds(true);
        //this.shop.sprite.setCollideWorldBounds(true);

        const camera = this.cameras.main;
        camera.startFollow(this.player.sprite);
        camera.setBounds(0, 0, map.widthInPixels*2, map.heightInPixels*2);

        // Help text that has a "fixed" position on the screen
        this.add.text(16, 16, 'Arrow keys to move\nPress "D" to show hitboxes', {
              font: "18px monospace",
              fill: "#000000",
              padding: { x: 20, y: 10 },
              backgroundColor: "#ffffff"
         }).setScrollFactor(0).setDepth(30);

        // Debug graphics
        this.input.keyboard.once("keydown_D", event => {
        // Turn on physics debugging to show player's hitbox
            this.physics.world.createDebugGraphic();
            // Create worldLayer collision graphic above the player, but below the help text
            const graphics = this.add.graphics().setAlpha(0.75).setDepth(20);
            this.walls.renderDebug(graphics, {
                tileColor: null, // Color of non-colliding tiles
                collidingTileColor: new Phaser.Display.Color(243, 134, 48, 255), // Color of colliding tiles
                faceColor: new Phaser.Display.Color(40, 39, 37, 255) // Color of colliding face edges
            });
        });

        //add player health bar
        var health = [];
        var xcoord = 30;
        var ycoord = 510;
        for(var i = 0; i < 10; i++) {
            health.push(this.add.image(xcoord + i*32,ycoord,'heart'));
            health[i].setScrollFactor(0);
        }
        this.add.text(xcoord, ycoord + 32, "Health").setScrollFactor(0);
    }

    update(time, delta) {
        this.player.update();

        if(this.tshop === true && !checkOverlap(this.player.sprite, this.shop.sprite)) {
            this.tshop = false;
        }

        //add interaction for player and shop
        this.physics.add.overlap(this.player.sprite, this.shop.sprite, check, null, this);

        function checkOverlap(player, shop) {
            var boundsA = player.getBounds();
            var boundsB = shop.getBounds();

            return Phaser.Geom.Intersects.RectangleToRectangle(boundsA, boundsB);
        }

        function check(){
            if(this.tshop != true){
                this.tshop = true;
                this.input.keyboard.once("keydown_A", event => {
                    this.currscene = 'LevelOneE';
                    this.player.x = this.player.sprite.x;               //to keep track of where the player sprite's x position was last at
                    this.player.y = this.player.sprite.y;               //to keep track of where the player sprite's y position was last at
                    this.scene.start('ShopScene', {player: this.player, shop: this.shop, scene: this.currscene});  //call the shop scene
                });
            }
        }
    }
}