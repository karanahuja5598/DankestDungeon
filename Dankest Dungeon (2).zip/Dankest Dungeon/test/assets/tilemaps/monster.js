export default class monster extends Phaser.Physics.Arcade.Image{
    constructor(scene, x, y){
        super(scene, x, y);
        this.scene = scene;
        this.x = x;
        this.y = y;
        this.sprite = this.scene.physics.add.sprite(x,y, "dragon");
        this.lmv = 0;

        

        this.sprite.setScale(2);

        const anims = scene.anims;
        anims.create({
            key: 'left',
            frames: anims.generateFrameNumbers("dragon", {start: 8, end: 11}),
            repeat: -1
        });
        anims.create({
            key: 'right',
            frames: anims.generateFrameNumbers("dragon", {start: 12, end: 15}),
            repeat: -1
        });
        anims.create({
            key: 'up',
            frames: anims.generateFrameNumbers("dragon", {start: 4, end: 7}),
            repeat: -1
        });
        anims.create({
            key: 'down',
            frames: anims.generateFrameNumbers("dragon", {start: 0, end: 3}),
            repeat: -1
        });


    }

    


    update(){

        function getRandomInt(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        var rand = getRandomInt(0,4);

        const speed = 175;

        const prevVelocity = this.sprite.body.velocity.clone();

        //this.sprite.body.setVelocity();

        this.sprite.body.setVelocity(0);

        //create a random number for the AI

        this.d = new Date();
        this.h = this.d.getTime(); 
        
        this.sprite.body.velocity.normalize().scale(speed);
        
        if(rand == 0 ){
            while((this.h - this.lmv) > 2000){
                console.log("print");
                this.sprite.body.setVelocityY(-speed);
                this.sprite.anims.play("left", true);
                // if((this.h - this.lmv) === 1999){
                //     this.lmv = this.h;
                //     break;
                // }
            }
        }
        // else if (rand == 1){
        //     while((this.h - this.lmv) < 2000){
        //         this.sprite.body.setVelocityY(speed);
        //         this.sprite.anims.play("right", true);
        //         if((this.h - this.lmv) === 1998){
        //             this.lmv = this.h;
        //             break;
        //         }
        //     }
            
        // }else if(rand == 2){
        //     while((this.h - this.lmv) < 2000){
        //         this.sprite.body.setVelocityX(-speed);
        //         this.sprite.anims.play("up", true);
        //         if((this.h - this.lmv) === 1998){
        //             this.lmv = this.h; 
        //             break;
        //         }
        //     }
            
        // }else if(rand == 3){
        //     while((this.h - this.lmv) < 2000){
        //         this.sprite.body.setVelocityX(speed);
        //         this.sprite.anims.play("down", true);
        //         if((this.h - this.lmv) === 1998){
        //             this.lmv = this.h;
        //             break;
        //         }
        //     }
            
        // }

    }

    
}