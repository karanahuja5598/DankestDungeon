import Potion from "./potion.js";
class FirePotion extends Potion {};
class IcePotion extends Potion {};
class ExplosionPotion extends Potion {};
class AcidPotion extends Potion {};

export default class Shopkeeper extends Phaser.Physics.Arcade.Image{
    constructor(scene, x, y, inventory) {
        super(scene, x, y);
        this.scene = scene;
        this.sprite = this.scene.physics.add.sprite(x, y, "shopkeeper");
        this.inventory = inventory; // create empty array
        this.money = 0;
        //this.scene.children.add(this);
        //this.scene.physics.add.existing(this);
        this.x = x;
        this.y = y;
        this.sprite.setScale(2);
    }

    sell(player, item){
        if(item != null){
            if(this.money >= item.cost){
                this.inventory.push(item);
                this.index = player.inventory.indexOf(item);
                player.inventory.splice(this.index, 1);
                player.money += item.cost;
                this.money -= item.cost;
            }
            else{
                console.log("Shop has no money");     //UI stuff to do
            }
        }
        else{
            console.log("Player has no items");          //UI stuff to do
        }
    }

    buy(player, item){
        if(item != null){
            console.log(player.money);
            console.log(item.cost);
            if(player.money >= item.cost){
                player.inventory.push(item);
                this.index = this.inventory.indexOf(item);
                this.inventory.splice(this.index, 1);
                player.money -= item.cost;
                this.money += item.cost;
            }
            else{
                console.log("Not enough money");        //UI stuff to do
            }
        }
        else{
            console.log("Shop has no items");      //UI stuff to do
        }
    }

}
