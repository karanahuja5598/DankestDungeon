export default class ShopScene extends Phaser.Scene {
    constructor(){
        super("ShopScene");
    }

    create(data){

        this.player = data.player;
        this.shop = data.shop;
        var buttonBuy = this.add.image(400, 300, 'BuyB');
        var buttonSell = this.add.image(400, 350, 'SellB');
        var buttonExit = this.add.image(400, 400, 'exit');

        buttonBuy.setInteractive();
        buttonBuy.on("pointerdown", () => {
            this.inventory = this.shop.inventory;

            if(this.inventory.length > 0){
                buttonBuy.destroy();
                buttonSell.destroy();
                buttonExit.destroy();
                this.posy = 150;
                //Dynamically create the list of items a shop has
                this.inventory.forEach(item => {
                    this.add.image(400, this.posy, item.image).setInteractive().on("pointerdown", () => {
                        this.shop.buy(this.player, item);
                        this.scene.start('ShopScene');
                    });
                    this.posy += 50;
                });
                this.buttonReturn = this.add.image(400, this.posy, 'Return');
                this.buttonReturn.setInteractive().on("pointerdown", () => { this.scene.start('ShopScene'); });
            }
            else{
                var x = this.add.text(250, 500, 'The shop doesnt have any items to sell');
                setTimeout(function () {x.destroy()}, 2000);
            }
        });

        buttonSell.setInteractive();
        buttonSell.on("pointerdown", () => {
            this.inventory = this.player.inventory;
            if(this.inventory.length > 0){
                buttonBuy.destroy();
                buttonSell.destroy();
                buttonExit.destroy();
                this.posy = 150;
                //Dynamically create the list of items a shop has
                this.inventory.forEach(item => {
                    this.add.image(400, this.posy, item.image).setInteractive().on("pointerdown", () => {
                        this.shop.sell(this.player, item);
                        console.log(item.name);
                        this.scene.start('ShopScene');
                     });
                    this.posy += 50;
                });
                this.buttonReturn = this.add.image(400, this.posy, 'Return');
                this.buttonReturn.setInteractive().on("pointerdown", () => { this.scene.start('ShopScene');});
            }
            else{
                var x = this.add.text(250, 500, 'You dont have any items to sell');
                setTimeout(function () {x.destroy()}, 2000);
            }
        });

        buttonExit.setInteractive();
        buttonExit.on("pointerdown", () => { this.scene.start(data.scene, {player: this.player, shop: this.shop}); });

    }
}