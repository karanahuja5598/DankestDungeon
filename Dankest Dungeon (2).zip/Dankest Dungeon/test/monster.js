export default class Monster extends Phaser.Physics.Arcade.Image{
    constructor(scene, x, y){
        super(scene, x, y);
        this.scene = scene;
        this.x = x;
        this.y = y;
        this.sprite = this.scene.physics.add.sprite(x,y, "dragon");
        this.lmv = 0;
        this.ENEMY_SPEED = 175;

        this.left = false;
        this.right = false;
        this.down = false;
        this.up = false;

        this.sprite.setScale(2);

        const anims = scene.anims;
        anims.create({
            key: 'left',
            frames: anims.generateFrameNumbers("dragon", {start: 8, end: 11}),
            repeat: -1
        });
        anims.create({
            key: 'right',
            frames: anims.generateFrameNumbers("dragon", {start: 12, end: 15}),
            repeat: -1
        });
        anims.create({
            key: 'up',
            frames: anims.generateFrameNumbers("dragon", {start: 4, end: 7}),
            repeat: -1
        });
        anims.create({
            key: 'down',
            frames: anims.generateFrameNumbers("dragon", {start: 0, end: 3}),
            repeat: -1
        });
        anims.create({
            key: 'idle-left',
            frames: anims.generateFrameNumbers("dragon", {start: 11, end: 11}),
            repeat: -1
        });
        anims.create({
            key: 'idle-right',
            frames: anims.generateFrameNumbers("dragon", {start: 15, end: 15}),
            repeat: -1
        });
        anims.create({
            key: 'idle-up',
            frames: anims.generateFrameNumbers("dragon", {start: 5, end: 5}),
            repeat: -1
        });
        anims.create({
            key: 'idle-down',
            frames: anims.generateFrameNumbers("dragon", {start: 0, end: 0}),
            repeat: -1
        });
    }

    update(cursor, player, game){
        this.chaseMe(player);
        this.monsterMovement();
    }

    monsterMovement(){
        var rand = this.getRandomInt(0,4);
        const speed = 175;
        this.sprite.body.velocity.normalize().scale(speed);

        //create a random number for the AI
        this.d = new Date();
        this.h = this.d.getTime();

        if (this.h - this.lmv > 1500) {
            if (rand === 0) {
                this.sprite.body.setVelocityX(-speed);
                this.sprite.anims.play("left", true);
                this.lmv = this.h;
                this.left = true;
            } else if (rand === 1) {
                this.sprite.body.setVelocityX(speed);
                this.sprite.anims.play("right", true);
                this.lmv = this.h;
                this.right = true;
            } else if (rand === 2) {
                this.sprite.body.setVelocityY(speed);
                this.sprite.anims.play("down", true);
                this.lmv = this.h;
                this.down = true;
            } else if (rand === 3) {
                this.sprite.body.setVelocityY(-speed);
                this.sprite.anims.play("up", true);
                this.lmv = this.h;
                this.up = true;
            }
        }

        if(this.left === true && (this.h - this.lmv > 750)){
            this.sprite.body.setVelocity(0);
            this.sprite.anims.play("idle-left", true);
            this.lmv = this.h;
            this.left = false;
        }
        else if(this.right === true && (this.h - this.lmv > 750)){
            this.sprite.body.setVelocity(0);
            this.sprite.anims.play("idle-right", true);
            this.lmv = this.h;
            this.right = false;
        }
        else if(this.down === true && (this.h - this.lmv > 750)){
            this.sprite.body.setVelocity(0);
            this.sprite.anims.play("idle-down", true);
            this.lmv = this.h;
            this.down = false;
        }
        else if(this.up === true && (this.h - this.lmv > 750)){
            this.sprite.body.setVelocity(0);
            this.sprite.anims.play("idle-up", true);
            this.lmv = this.h;
            this.up = false;
        }
    }

    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    chaseMe(player) {
        //lets assume 10 pixels difference if needed
        var diffPlusX = player.x + 10; // line of sight at 10 pixels high on x
        var diffMinusX = player.x - 10; // line of sight at -10 pixels high on x
        var diffPlusY = player.y + 10; // line of sight at 10 pixels high on y
        var diffMinusY = player.y - 10; // line of sight at -10 pixels high on y
        var howClose = 130; // how close is does the enemy start chasing you

        if (Math.floor(this.sprite.y) == (Math.floor(player.y))
            || Math.floor(this.sprite.y) < (Math.floor(diffPlusY))
            && Math.floor(this.sprite.y) > (Math.floor(diffMinusY))){
            // in the line of sight on horizontal line
            if (player.x > this.sprite.x + howClose){
                this.sprite.body.velocity.x = this.ENEMY_SPEED;
                this.sprite.anims.play("right", true);
                //this.sprite.body.velocity.y = 0; // remove this if you want enemy chanse diagonal
            } else
            if (player.x < this.sprite.x - howClose)
            {
                this.sprite.body.velocity.x = -this.ENEMY_SPEED;
                this.sprite.anims.play("left", true);
                //this.sprite.body.velocity.y = 0; // remove this if you want enemy chanse diagonal
            }
        }
        if (Math.floor(this.sprite.x) == (Math.floor(player.x))
            || Math.floor(this.sprite.x) < (Math.floor(diffPlusX))
            && Math.floor(this.sprite.x) > (Math.floor(diffMinusX))){
            // in the line of sight on vertical line
            if (player.y > this.sprite.y + howClose){
                this.sprite.body.velocity.y = this.ENEMY_SPEED;
                this.sprite.anims.play("down", true);
                //this.sprite.body.velocity.x = 0
            } else
            if (player.y < this.sprite.y - howClose)
            {
                this.sprite.body.velocity.y = -this.ENEMY_SPEED;
                this.sprite.anims.play("up", true);
                //this.sprite.body.velocity.x = 0
            }
        }


    }
}