export default class Wall {
    constructor(scene, x, y, image){
        this.scene = scene;
        this.sprite = this.scene.physics.add.sprite(x,y,image);
        this.x = x;
        this.y = y;
        this.sprite.setScale(2);
    }
}

class IceWall extends Wall {
    constructor(scene, x , y, image){
        super(scene, x, y, image);
        //this.sprite = this.scene.physics.add.sprite(x, y, "dragon");
    }
}

class AcidWall extends Wall {
    constructor(scene, x, y, image){
        super(scene, y, y);
        this.sprite = this.scene.physics.add.sprite(x, y, "dragon");
        this.break = "acid";
    }


}