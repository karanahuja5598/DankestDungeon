

export default class MeanMenu extends Phaser.Scene{

    constructor(){
        super("MeanMenu");
    }

    preload(){
        this.load.spritesheet('startButton', "../assets/images/Start-Game.png", {frameWidth: 100, frameHeight: 100})
        this.load.image('logo', '../assets/images/danklogo.png');
        this.load.image('background', '../assets/images/menu-background.jpg');
    }

    create(){

        var background = this.add.image(400,300,'background');
        background.setAlpha(0.3);

        var logo = this.add.image(400,200,'logo');
        logo.setScale(2);

        this.input.keyboard.addKey('ESC');

        //set up the start button
        var button = this.add.image(400, 400, 'startButton');
        button.setInteractive();
        button.on("pointerdown", () => {this.scene.start("LevelOne");});
    }


}
