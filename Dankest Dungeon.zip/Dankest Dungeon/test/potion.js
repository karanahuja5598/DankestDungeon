export default class Potion {
    constructor(cost, damage, radius, toss, name, button){
        this.cost = cost;
        this.damage = damage;
        this.radius = radius;
        this.toss = toss;
        this.name = name;
        this.image = button;
    }

    use(){
    }
}

class IcePotion extends Potion {
    constructor(cost, damage, radius, toss, name, button){
        super(cost, damage, radius, toss, name, button);
    }

    use(item, player){
        this.index = player.inventory.indexOf(item);

        player.inventory.splice(this.index, 1);
    }
}

class FirePotion extends Potion {
    constructor(cost, damage, radius, toss, name, button){
        super(cost, damage, radius, toss, name, button);
    }
}

class ExplosionPotion extends Potion {
    constructor(cost, damage, radius, toss, name, button){
        super(cost, damage, radius, toss, name, button);
    }
}

class AcidPotion extends Potion {
    constructor(cost, damage, radius, toss, name, button){
        super(cost, damage, radius, toss, name, button);
        this.break = "acid";
    }
}