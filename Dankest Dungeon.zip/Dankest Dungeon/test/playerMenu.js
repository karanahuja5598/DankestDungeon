export default class PlayerMenu extends Phaser.Scene {
    constructor(){
        super('PlayerMenu');
    }

    create(data){
        this.player = data.player;
        this.inventory = this.add.image(100, 200, "Inventory");

        this.add.image(600, 100, "dragon").setScale(4);

        //Character Stats
        this.add.text(540, 170, 'Character Stats:');

        var x = this.add.text(500, 200, 'Health: ');
        this.add.text(570, 200, this.player.health);

        this.add.text(630, 200, 'Currency: ');
        this.add.text(720, 200, this.player.money);

        this.inventory.setInteractive().on("pointerdown", () => {
            this.inventory.destroy();

            this.posy = 100;

            this.player.inventory.forEach(item => {
                this.add.image(100, this.posy, item.image);
                this.posy += 50;
            });
        });

        var buttonExit = this.add.image(750, 25, 'exit');
        buttonExit.setInteractive().on("pointerdown", () => {
            this.scene.start(data.scene, {player: this.player, shop: data.shop});
        });
    }
}