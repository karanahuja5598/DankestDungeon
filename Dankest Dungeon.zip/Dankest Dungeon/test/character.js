export default class Character extends Phaser.Physics.Arcade.Image {
    constructor(scene, x, y, inventory, health, score){
        super(scene, x, y);
        this.scene = scene;
        //this.scene.children.add(this);
        //this.scene.physics.add.existing(this);
        this.sprite = this.scene.physics.add.sprite(x, y, "dragon");
        this.inventory = inventory;         //character inventory
        this.money = 100;                   //Money the player has
        this.x = x;                         //character x position
        this.y = y;                         //character y position
        this.sprite.setScale(2);
        this.health = health;
        this.healthI = [];
        this.lastHurt = 0;
        this.lastHealth = 0;
        this.nextLevel = false;
        this.p = 0;
        this.score = score;

        this.cursors = scene.input.keyboard.createCursorKeys();
        // Create the player's walking animations from the texture atlas. These are stored in the global
                // animation manager so any sprite can access them.
        const anims = scene.anims;
        anims.create({
            key: 'left',
            frames: anims.generateFrameNumbers("dragon", {start: 8, end: 11}),
            repeat: -1
        });
        anims.create({
            key: 'right',
            frames: anims.generateFrameNumbers("dragon", {start: 12, end: 15}),
            repeat: -1
        });
        anims.create({
            key: 'up',
            frames: anims.generateFrameNumbers("dragon", {start: 4, end: 7}),
            repeat: -1
        });
        anims.create({
            key: 'down',
            frames: anims.generateFrameNumbers("dragon", {start: 0, end: 3}),
            repeat: -1
        });
        anims.create({
            key: 'idle-left',
            frames: anims.generateFrameNumbers("dragon", {start: 11, end: 11}),
            repeat: -1
        });
        anims.create({
            key: 'idle-right',
            frames: anims.generateFrameNumbers("dragon", {start: 15, end: 15}),
            repeat: -1
        });
        anims.create({
            key: 'idle-up',
            frames: anims.generateFrameNumbers("dragon", {start: 5, end: 5}),
            repeat: -1
        });
        anims.create({
            key: 'idle-down',
            frames: anims.generateFrameNumbers("dragon", {start: 0, end: 0}),
            repeat: -1
        });
    }

    //method that updates the health bar according to the players health
    updateHealth(scene, item){
        if(item != 0){
            if((scene.h - this.lastHealth) > 1000){
                this.p += 1;
                this.lastHealth = scene.h;
                this.healthI.push(scene.add.image(scene.xcoord + this.p*32, scene.ycoord,'heart'));
                this.healthI[this.p].setScrollFactor(0);
                this.health += 10;
            }
        }
        else{
            var p = this.healthI.length - 1;
            this.healthI[p].destroy();
            this.healthI.pop();
            this.p--;
            this.health -= 10;
        }
    }

    update(){
        const speed = 175;
        const prevVelocity = this.sprite.body.velocity.clone();
        //const { keys, sprite } = this;

        // Stop any previous movement from the last frame
        this.sprite.body.setVelocity(0);
        //cursors = this.input.keyboard.createCursorKeys();
        // Horizontal movement
        if (this.cursors.left.isDown) {
            this.sprite.body.setVelocityX(-speed);
            this.score += 10;
        }
        else if (this.cursors.right.isDown) {
            this.sprite.body.setVelocityX(speed);
            this.score += 10;
        }

        // Vertical movement
        if (this.cursors.up.isDown) {
            this.sprite.body.setVelocityY(-speed);
            this.score += 10;
        }
        else if (this.cursors.down.isDown) {
            this.sprite.body.setVelocityY(speed);
            this.score += 10;
        }

        // Normalize and scale the velocity so that player can't move faster along a diagonal
        this.sprite.body.velocity.normalize().scale(speed);

        // Update the animation last and give left/right animations precedence over up/down animations
        if (this.cursors.left.isDown) {
            this.sprite.anims.play("left", true);
        }
        else if (this.cursors.right.isDown) {
            this.sprite.anims.play("right", true);
        }
        else if (this.cursors.up.isDown) {
            this.sprite.anims.play("up", true);
        }
        else if (this.cursors.down.isDown) {
            this.sprite.anims.play("down", true);
        }
        else {
            this.sprite.anims.stop();

            if (prevVelocity.x < 0)      this.sprite.anims.play("idle-left", true);
            else if (prevVelocity.x > 0) this.sprite.anims.play("idle-right", true);
            else if (prevVelocity.y < 0) this.sprite.anims.play("idle-up", true);
            else if (prevVelocity.y > 0) this.sprite.anims.play("idle-down", true);
        }
    }
}
