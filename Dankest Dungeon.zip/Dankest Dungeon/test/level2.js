import Shopkeeper from './shopkeeper.js';
import Character from './character.js';
import Monster from "./monster.js";
import Potion from './potion.js';
class FirePotion extends Potion {};
class IcePotion extends Potion {};
class ExplosionPotion extends Potion {};
class AcidPotion extends Potion {};

export default class LevelTwo extends Phaser.Scene {
    constructor(){
        super('LevelTwo');
    }

    preload() {
        this.load.image("tiles", "../assets/tilesets/dungeonTileset.png");
        this.load.tilemapTiledJSON("map2", "../assets/tilemaps/lvl2.json");
        //this.load.spritesheet("dragon", "../assets/images/FlameTail v2.png", {frameWidth: 16, frameHeight: 16});
        //this.load.spritesheet("shopkeeper", "../assets/images/Shopkeeper.png", {frameWidth: 16, frameHeight: 16});
        //this.load.image("heart", "../assets/images/heart.png");
        //this.load.image("button", "../assets/images/button_button.png");
        //this.load.image("exit", "../assets/images/button_exit.png");
        //this.load.image("BuyB", "../assets/images/button_buy.png");
        //this.load.image("SellB", "../assets/images/button_sell.png");
        //this.load.image("FireP", "../assets/images/button_fire-potion.png");
        //this.load.image("IceP", "../assets/images/button_ice-potion.png");
        //this.load.image("ExplosionP", "../assets/images/button_explosion-potion.png");
        //this.load.image("AcidP", "../assets/images/button_acid-potion.png");
        //this.load.image("Return", "../assets/images/button_return.png");
        this.load.image("Inventory", "../assets/images/button_inventory.png");
    }

    create(data){
        const map = this.make.tilemap({ key: "map2" });
        this.currscene = 'LevelTwo';

        this.xcoord = 30;
        this.ycoord = 510;
        this.pos = 0;

        const tileset = map.addTilesetImage("dungeonTileset", "tiles");
        this.floor = map.createStaticLayer("Floor", tileset, 0, 0);
        this.walls = map.createStaticLayer("Wall", tileset, 0, 0);
        this.decorations = map.createStaticLayer("Decoration", tileset, 0, 0);
        this.items = map.createStaticLayer("Items", tileset, 0, 0);

        //scale up everything
        this.walls.setScale(2);
        this.floor.setScale(2);
        this.decorations.setScale(2);
        this.items.setScale(2);

        //set the collision property
        this.walls.setCollisionByProperty({ collides: true });
        this.decorations.setCollisionByProperty({ collides: true });
        this.items.setCollisionByProperty( {collides: true });

        //create the spawn point for the character
        const spawnPoint = map.findObject("Spawn", obj => obj.name === "Spawn Point");
        const shopSpawn = map.findObject("Shop", obj => obj.name === "Shop Spawn");

        //object layer spawnpoint for the monsters
        const monsterPoint = map.findObject("Monster Spawn", obj => obj.name === "Monster");

        //create the player character and the shopkeeper
        if(data.player.nextLevel === true){
            this.player = new Character(this, spawnPoint.x, spawnPoint.y, data.player.inventory, data.player.health, data.player.score);
        }
        else{
            this.player = new Character(this, data.player.x, data.player.y, data.player.inventory, data.player.health, data.player.score);
        }

        //create the shopkeeper
        this.shop = new Shopkeeper(this, shopSpawn.x*2, shopSpawn.y*2, data.shop.inventory);
        //create the monster
        this.monster = new Monster(this, monsterPoint.x*2, monsterPoint.y*2);

        // Watch the player and worldLayer for collisions, for the duration of the scene:
        this.physics.world.addCollider(this.player.sprite, this.walls);
        this.physics.world.addCollider(this.player.sprite, this.decorations);
        this.physics.world.addCollider(this.player.sprite, this.items);

        // Watch the monster and worldLayer for collisions, for the duration of the scene:
        this.physics.world.addCollider(this.monster.sprite, this.walls);
        this.physics.world.addCollider(this.monster.sprite, this.obstacle);

        //if we reach the door to the level
        this.decorations.setTileIndexCallback(451, this.nextLevel, this);
        this.decorations.setTileIndexCallback(69, this.decreaseHealth, this);
        this.items.setTileIndexCallback(531, this.upHealth, this);
        this.decorations.setTileIndexCallback(37, destroyObject, this);

        //Destroy the object
        function destroyObject(sprite, tile){
            this.player.x = this.player.sprite.x;
            this.player.y = this.player.sprite.y;
            //this.decorations.destroy();
        }

        this.input.keyboard.once("keydown_I", event => {
            this.player.x = this.player.sprite.x;               //to keep track of where the player sprite's x position was last at
            this.player.y = this.player.sprite.y;               //to keep track of where the player sprite's y position was last at
            this.scene.start('InventoryScene', {scene: this, player: this.player, shop: this.shop});  //call the shop scene
        });

        this.input.keyboard.once("keydown_M", event => {
            this.player.x = this.player.sprite.x;
            this.player.y = this.player.sprite.y;
            this.scene.start('PlayerMenu', {scene: this, player: this.player, shop: this.shop});
        });

        this.input.keyboard.once("keydown_ESC", event => {
            this.scene.start('MeanMenu');
        });

        //camera
        const camera = this.cameras.main;
        camera.startFollow(this.player.sprite);
        camera.setBounds(0, 0, map.widthInPixels*2, map.heightInPixels*2);

        //add player health bar
        for(var i = 0; i < this.player.health/10; i++) {
            this.player.p = i;
            this.player.healthI.push(this.add.image(this.xcoord + i*32 , this.ycoord,'heart'));
            this.player.healthI[i].setScrollFactor(0);
        }
        this.add.text(this.xcoord, this.ycoord + 32, "Health").setScrollFactor(0);
    }

    update(time, delta){
        this.player.update();
        this.monster.update(this.player.sprite);

        this.add.text(650, 16, 'Score: ' + this.player.score, {
              font: "18px monospace",
              fill: "#000000",
              padding: { x: 20, y: 10 },
              backgroundColor: "#ffffff"
        }).setScrollFactor(0).setDepth(30);

        this.d = new Date();
        this.h = this.d.getTime();

        if(this.tshop === true && !this.checkOverlap(this.player.sprite, this.shop.sprite)) {
            this.tshop = false;
        }

        //add interaction for player and shop
        this.physics.add.overlap(this.player.sprite, this.shop.sprite, this.check, null, this);
    }

    //Decrease player's health accordingly
    decreaseHealth(sprite, tile){
        if((this.h - this.player.lastHurt) > 1000) {
            this.player.lastHurt = this.h;
            this.player.updateHealth(this, 0);
        }
    }

    //Increase the player's health accordingly
    upHealth(sprite, tile){
        this.player.updateHealth(this, 1);
    }

    checkOverlap(player, shop) {
        var boundsA = player.getBounds();
        var boundsB = shop.getBounds();

        return Phaser.Geom.Intersects.RectangleToRectangle(boundsA, boundsB);
    }

    check(){
        if(this.tshop != true){
            this.tshop = true;
            this.input.keyboard.once("keydown_A", event => {
                this.player.x = this.player.sprite.x;               //to keep track of where the player sprite's x position was last at
                this.player.y = this.player.sprite.y;               //to keep track of where the player sprite's y position was last at
                this.scene.start('ShopScene', {player: this.player, shop: this.shop, scene: this.currscene});  //call the shop scene
            });
        }
    }

    //Transition to the next level
    nextLevel(sprite, tile){
        this.player.x = 0;
        this.player.y = 0;
        this.player.nextLevel = true;
        this.scene.start('LevelTwo', {player: this.player, shop: this.shop});
    }
}