export default class InventoryScene extends Phaser.Scene {
    constructor(){
        super('InventoryScene');
    }

    create(data){
        this.player = data.player;
        this.posy = 150;

        if(this.player.inventory.length > 0){
            this.player.inventory.forEach(item => {
                console.log("FUCK");
                this.add.image(400, this.posy, item.image).setInteractive().on("pointerdown", () => {
                    item.use(item, this.player);
                    this.scene.start('InventoryScene');
                });
                this.posy += 50;
            });
        }
        else{
            var x = this.add.text(200, 500, 'You dont have any items in your inventory');
            setTimeout(function () {x.destroy()}, 2000);
        }
        var buttonExit = this.add.image(750, 25, 'exit');
        buttonExit.setInteractive().on("pointerdown", () => {
            this.scene.start(data.scene, {player: this.player, shop: data.shop});
        });

    }

}