import LevelOne from "./level1.js";
import MeanMenu from "./menu.js";
import ShopScene from "./shopScene.js";
import LevelOneE from "./level1E.js";
import LevelTwo from "./level2.js";
import InventoryScene from "./InventoryScene.js";
import PlayerMenu from "./playerMenu.js";

var arr = [MeanMenu ,LevelOne, ShopScene, LevelOneE, LevelTwo, InventoryScene, PlayerMenu];

const config = {
  type: Phaser.WEBGL,
  width: 800,
  height: 600,
  backgroundColor: "#000",
  parent: "game-container",
  pixelArt: true,
  scene: arr,
  physics: {
      default: "arcade",
      arcade: {
        gravity: { y: 0 }
      }
    }
};

var game = new Phaser.Game(config);
var g;

function create(){
    g = this;
};
